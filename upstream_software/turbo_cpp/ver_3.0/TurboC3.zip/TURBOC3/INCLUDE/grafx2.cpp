/****************************************************************************/
/* Librairie de fonctions graphiques   					                    */
/*                                                                          */
/* Shaun "Krashlog" Dore                                                    */
/* http://pages.infinit.net/shaun                                           */
/* 20 Avril 1998                                                            */
/*                                                                          */
/* Note: Nouvelle version en assembleur                                     */
/*                                                                          */
/****************************************************************************/


#include <dos.h>
#include <alloc.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <graphics.h>

#define vga 0xA000
#define pi 3.1415927

typedef unsigned char byte;
typedef unsigned int word;

byte far *virscr=NULL;
word vaddr;


/*-----------------------------------*/
/* FONCTIONS ADDED BY JOSH83         */
/*-----------------------------------*/

//key watcher
unsigned char inkey(void)
{
asm in al,0x60
}

//For pausing
void Pause(int p)
{
int waiting;
for(waiting=0;waiting<p;waiting++)
{}
}

//BGI installer
void SetBGI(void)
{
int gdriver = DETECT, gmode, errorcode;
initgraph(&gdriver, &gmode, "");
errorcode = graphresult();
if (errorcode != grOk)
  {
  printf("Graphics error: %s BGI not initalized\n", grapherrormsg(errorcode));
  printf("Wait to quit...");
  getch();
  exit(1);
  }
}

//BGI desinstaller
void ShutBGI(void)
{
closegraph();
}


/******************************** FONCTIONS *********************************/

//GETPIXEL WRITTEN BY JOSH83

byte GetPixel(int x,int y,word where)
{
char far *vram = (char far*) MK_FP(where, 0);
return vram[x+(y*320)];
}

void Putpixel (word x, word y, byte col, word where)
{
 asm {
   mov     ax, [where]  // AX pointe sur l'adresse where
   mov     es, ax       // ES = VGA
   mov     bx, [x]      // BX = X
   mov     dx, [y]      // DX = Y
   mov     ah, dl       // AH = Y*256
   xor     al, al       // AX = Y*256
   shl     dx, 6        // DX = Y*64 par decalage a gauche
   add     dx, ax       // DX = Y*320
   add     bx, dx       // BX = Y*320 + X
   mov     ah, [col]    // col dans AH
   mov     byte ptr es:[bx], ah  // mettre AH a l'offset bx (DI)
 }
}


void Cls(word where, byte Col)
/****************************************************************************/
/* Cls - Vide l'ecran "where" de la couleur "Col"		                    */
/****************************************************************************/
{
  asm {
   push    es           // Extra segment sauvegarde
   mov     cx, 32000;   // Mets dans CX 32000
   mov     es,[where]   // Extra segment dans Where
   xor     di,di        // Mise a zero du Destination Index
   mov     al,[Col]     // Mets Col dans AL
   mov     ah,al        // Mets AL dans AH (SEG:OFF)
   rep     stosw        // stosw = store single word
   pop     es           // remet ancienne valeur de es
   }
}


void Flip(word source, word dest)
/****************************************************************************/
/* Flip - Copie le contenue de la memoire vers l'ecran		                */
/****************************************************************************/
{
  asm {
   push    ds           // Segment de donnee sauvegarde
   mov     ax, [dest]   // Mets l'adresse de notre segment d'arrive dans AX
   mov     es, ax       // Sauve le contenu de AX dans l'Extra Segment (ES)
   mov     ax, [source] // Mets l'adresse de notre segment source dans AX
   mov     ds, ax       // Sauve le contenu de AX dans le Data Segment (DS) (ecrase l'ancien)
   xor     si, si       // OU exclusif logique (1 OU l'autre mais pas 1 ET l'autre)
   xor     di, di       // XOR est utilise pour mettre les Index source et dest � 0
   mov     cx, 32000    // Mets dans CX 32000 bytes
   rep     movsw        // movsw = mov single word 32000x
   pop     ds           // remet notre ancienne valeur de DS sauv�e par push
  }
}


void SetVGA()
/****************************************************************************/
/* SetVGA - Cette fonction vous mets en mode 320x200x256		            */
/****************************************************************************/
{
  asm {
	   mov ax, 0x0013  // Mets dans le registre AX 0013h
	   int 0x10        // appel l'interruption 10h (carte video)
	  }
}


void SetText()
/****************************************************************************/
/* SetText - Cette fonction vous mets en mode texte 80 lignes	            */
/****************************************************************************/
{
  asm {
	   mov ax, 0x0003 // Mets dans le registre AX 0003h
	   int 0x10       // appel l'interruption 10h (carte video)
	  }
}

void SetPal(byte col, byte r, byte g, byte b)
/****************************************************************************/
/* SetPal- Cette fonction modifie les attributs RGB d'une couleur           */
/****************************************************************************/
{
  asm {
	   mov    dx,0x03c8  // DX recoit les infos du port 3C8 (Pel Write Adr)
	   mov    al,[col]   // AL recoit la couleur de la palette
	   out    dx,al      // out == envoie l'info vers les ports p�riph�riques
	   inc    dx         // Ajoute 1 a DX donc 3C9 (Pel Data)
	   mov    al,[r]     // (r)ed dans AL
	   out    dx,al      // envoie dans 3C9 (DX) le contenu de AL (r == rouge)
	   mov    al,[g]     // (g)reen est maintenant dans AL
	   out    dx,al      // envoie dans 3C9 (DX) le contenu de AL (g == green)
	   mov    al,[b]     // (b)lue maintenant dans AL
	   out    dx,al      // envoie le tout dans l'Input Status 1 (0x3C9)
	  }
}


void GetPal(byte col, byte &r, byte &g, byte &b)
/****************************************************************************/
/* GetPal- Cette fonction lit les attributs RGB d'une couleur               */
/****************************************************************************/
{
   byte rr, gg, bb; // Variables tempos

   asm {
	mov    dx, 0x03C7  // DX recoit les infos du port 3C7 (Pel Read Adr)
	mov    al, [col]   // AL recoit la couleur de la palette
	out    dx, al      // Envoie a 3c7 la couleur contenu dans AL
	add    dx, 2       // Ajoute 2 a DX pour etre sur 0x3c9 (Pel Data)
	in     al, dx      // in == lit l'info des ports peripheriques
	mov    [rr],al     // rr contient le contenu de AL (red)
	in     al, dx      // AL recoit l'info de 0x3c9
	mov    [gg],al     // gg contient le contenu de AL (green)
	in     al, dx      // AL recoit l'info de 0x3c9
	mov    [bb],al     // bb contient le contenu de AL (blue)
	   }

  r = rr;
  g = gg;  // transfer des variables tempos aux vrai variables rgb
  b = bb;
}


void SetVirtual()
/****************************************************************************/
/* SetVirtual - Alloue 64k d'espace memoire pour notre ecran virtuel	    */
/****************************************************************************/
{
  //unsigned char far vir[64000];
  virscr = (byte far *) farcalloc(64000, 1);   // Allocation de 64000 bits
  vaddr = FP_SEG(virscr); // vaddr contient l'adresse de depart du segment
  if(virscr==NULL)
  {
	 SetText();
	 printf("Pas assez de memoire pour l'ecran virtuel!\n");
	 exit(1);
  }
}


void FreeVirtual()
/****************************************************************************/
/* FreeVirtual() - Libere les 64k de notre ecran virtuel           	        */
/****************************************************************************/
{
  farfree(virscr);  // libere la memoire alloue
}


void WaitRetrace()
/****************************************************************************/
/* WaitRetrace - Cette fonction attend la retrace verticale                 */
/****************************************************************************/
{
  _DX = 0x03da;     // c'est egal � mov AX, 0x03da
  l1: asm {
	   in  al,dx    // recoit l'information de l'Input Status 1
	   and al,8     // ET logique sur 8hexa == 0000100
	   jnz l1       // si bit 3 == 0 le rayon dessine l'ecran
		  }         // jnz == loop tant que l1 == 1(attend la fin d'une
  l2: asm {         // retrace
	   in  al,dx    // recoit l'information de l'Input Status 1
	   and al,8     // sit bit 3 == 1 retrace verticale
	   jz  l2       // jz == loop tant que l2 == 0
		  }         // La retrace est amorce, on peut dessine
}


float Rad(float theta)
/****************************************************************************/
/* Rad - Cette fonction converti les degres en radians                      */
/****************************************************************************/

{
  return((theta*pi)/180);
}


int Round (long a)
/****************************************************************************/
/* Round - Cette fonction arrondi un nombre � l'entier le plus pret         */
/****************************************************************************/

{
  if ( (a - (int)a) < 0.5) return floor(a);
	else return ceil(a);
}


void Cercle(int X, int Y, int rad, int col, word where)
/****************************************************************************/
/* Cercle - Dessigne un cercle au coordonne (x,y), de rayon rad et de       */
/*          couleur col                                                     */
/****************************************************************************/
{
  float deg = 0;
  int x,y;

  do
  {
	x = Round(rad * cos(deg));
	y = Round(rad * sin(deg));
	Putpixel (X+x, Y+y, col,where);
	deg += 0.005;
  }
  while (deg <= 6.4);
}


/****************************************************************************/
/* Line - Dessine une ligne de x1,y1 a x2,y2 avec l'algo de Bresenham       */
/****************************************************************************/
void Line(short int x1, short int y1, short int x2, short int y2, byte col, word where)
{
 short int dx, dy, sdx, sdy, x, y, px, py;

 x = 0;
 y = 0;
 dx = x2 - x1;
 dy = y2 - y1;
 sdx = (dx < 0) ? -1 : 1;
 sdy = (dy < 0) ? -1 : 1;
 dx = sdx * dx + 1;
 dy = sdy * dy + 1;
 px = x1;
 py = y1;

 if (dx >= dy)
 {
	for (x = 0; x < dx; x++)
	{
		Putpixel(px,py,col,where);
		y += dy;
		if (y >= dx)
		{
			y -= dx;
			py += sdy;
		}
		px += sdx;
	}
 }
   else
 {
	for (y = 0; y < dy; y++)
	{
		Putpixel(px,py,col,where);
		x += dx;
		if (x >= dy)
		{
			x -= dy;
			px += sdx;
		}
		py += sdy;
	}
 }
}

byte Pal[256][3];

/****************************************************************************/
/* SavePal - Sauvegarde l'etat actuel de toute notre palette                */
/****************************************************************************/
void SavePal()
{
	for (int col=0; col<256; col++)
		GetPal(col,Pal[col][0],Pal[col][1],Pal[col][2]);
}


/****************************************************************************/
/* BlackPal -Ramene toutes les couleurs a 0 (BlackOut)                      */
/****************************************************************************/
void BlackPal()
{
   SavePal();
   WaitRetrace();
   for (int col=0;col<256;col++)
		 SetPal(col,0,0,0);
}

/****************************************************************************/
/* RestorePal -Ramene toutes les couleurs a leurs etat initial              */
/****************************************************************************/
void RestorePal()
{
   WaitRetrace();
   for (int col=0;col<256;col++)
		 SetPal(col,Pal[col][0],Pal[col][1],Pal[col][2]);
}

void LineClip(short int x1, short int y1, short int x2, short int y2, byte col, word where)
{
 short int dx, dy, sdx, sdy, x, y, px, py;

 x = 0;
 y = 0;
 dx = x2 - x1;
 dy = y2 - y1;
 sdx = (dx < 0) ? -1 : 1;
 sdy = (dy < 0) ? -1 : 1;
 dx = sdx * dx + 1;
 dy = sdy * dy + 1;
 px = x1;
 py = y1;

 if (dx >= dy)
 {
	for (x = 0; x < dx; x++)
	{
		if(px>0 && px<320)
		{
		if(py>0 && py<200)
		Putpixel(px,py,col,where);
		}
		y += dy;
		if (y >= dx)
		{
			y -= dx;
			py+= sdy;
		}
		px += sdx;
	}
 }
   else
 {
	for (y = 0; y < dy; y++)
	{
		if(px>0 && px<320)
		{
		if(py>0 && py<200)
		Putpixel(px,py,col,where);
		}
		x += dx;
		if (x >= dy)
		{
			x -= dy;
			px += sdx;
		}
		py += sdy;
	}
 }
}

