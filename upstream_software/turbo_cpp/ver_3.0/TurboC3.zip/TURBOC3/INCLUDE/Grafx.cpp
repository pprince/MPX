/****************************************************************************/
/* FICHIER     :  grafx.h                                                   */
/* AUTEUR      :  Shaun Dore                                                */
/* DATE        :  21 Fevrier 1998                                           */
/* VERSION     :  1.03                                                      */
/* DESCRIPTION :  Librairie graphique                                       */
/****************************************************************************/

#include <dos.h>
#include <mem.h>
#include <math.h>

typedef unsigned char byte;
char far *vga = (char far*) MK_FP(0xA000, 0);
byte Pal[256][3];

//key watcher added by josh83
unsigned char inkey(void)
{
asm in al,0x60
}

/****************************************************************************/
/* SetVGA - Appelle le mode 320x200x256 13h du BIOS                         */
/****************************************************************************/
void SetVGA()
{
  _AX = 0x0013;
  geninterrupt (0x10);
}


/****************************************************************************/
/* Putpixel - Affiche un pixel directement dans la memoire                  */
/****************************************************************************/
byte GetPixel(int x,int y)
{
return vga[x+(y*320)];
}



void Putpixel (int x, int y, byte col)
{
  memset(vga+x+(y*320),col,1);
}


/****************************************************************************/
/* SetText - Appelle le mode texte 03h du BIOS                              */
/****************************************************************************/
void SetText()
{
  _AX = 0x0003;
  geninterrupt (0x10);
}


/****************************************************************************/
/* Cls - Vide l'ecran avec la couleur col                                   */
/****************************************************************************/
void Cls(unsigned char col)
{
  memset(vga,col,0xffff);
}


/****************************************************************************/
/* SetPal- Cette fonction modifie les attributs RGB d'une couleur           */
/****************************************************************************/
void SetPal(byte col, byte r, byte g, byte b)
{
  outp (0x03C8,col);
  outp (0x03C9,r);
  outp (0x03C9,g);
  outp (0x03C9,b);

}


/****************************************************************************/
/* GetPal- Cette fonction lit les attributs RGB d'une couleur               */
/****************************************************************************/
void GetPal(byte col, byte &r, byte &g, byte &b)
{
   outp (0x03C7, col);
   r = inp (0x03C9);
   g = inp (0x03C9);
   b = inp (0x03C9);
}

/****************************************************************************/
/* WaitRetrace- Attend le debut d'un retour de balayage vertical            */
/****************************************************************************/
void WaitRetrace()
{
	_DX = 0x03da;       // meme chose que :  mov ax, 0x03da

	l1: asm {
			  in  al,dx // recoit l'information de l'Input Status 1
			  and al,8  // ET logique sur 8 hexa == 0000 0100
			  jnz l1    // si bit 3 == 0 le rayon dessine l'ecran
			}           // jnz == loop tant que l1 == 1
						// attend la fin d'une retrace
	l2: asm {
			  in  al,dx // recoit l'information de l'Input Status 1
			  and al,8  // si bit 3 == 1 retrace verticale
			  jz  l2    // jz == loop tant que l2 == 0
			}           // La retrace est amorce, on quitte la fonction
}


/****************************************************************************/
/* SavePal - Sauvegarde l'etat actuel de toute notre palette                */
/****************************************************************************/
void SavePal()
{
	for (int col=0; col<256; col++)
		GetPal(col,Pal[col][0],Pal[col][1],Pal[col][2]);
}


/****************************************************************************/
/* FadeOut - Ramene graduellement les valeurs RGB de toutes la palette a 0  */
/****************************************************************************/
void FadeOut()
{
	 unsigned char temp[3];
	 for (int rgb=0;rgb<64; rgb++)
	 {
		 WaitRetrace();
		 for (int col=0; col < 256; col++)
		 {
			 GetPal (col, temp[0], temp[1], temp[2]);
			 if (temp[0] > 0) temp[0]--;
			 if (temp[1] > 0) temp[1]--;
			 if (temp[2] > 0) temp[2]--;
			 SetPal (col, temp[0], temp[1], temp[2]);
		 }
	 }
}


/****************************************************************************/
/* FadeUp -Ramene graduellement toutes les couleurs a leurs etat initial    */
/****************************************************************************/
void FadeUp()
{
   byte temp[3];

   for (int rgb=0; rgb < 64; rgb++)
   {
	   WaitRetrace();
	   for (int col=0; col < 256; col++)
	   {
			 GetPal (col, temp[0], temp[1], temp[2]);
			 if ((temp[0] < Pal[col][0]) && (temp[0] < 63)) temp[0]++;
			 if ((temp[1] < Pal[col][1]) && (temp[1] < 63)) temp[1]++;
			 if ((temp[2] < Pal[col][2]) && (temp[2] < 63)) temp[2]++;
			 SetPal (col, temp[0], temp[1], temp[2]);
	   }
   }
}

/****************************************************************************/
/* BlackPal -Ramene toutes les couleurs a 0 (BlackOut)                      */
/****************************************************************************/
void BlackPal()
{
   SavePal();
   WaitRetrace();
   for (int col=0;col<256;col++)
		 SetPal(col,0,0,0);
}

/****************************************************************************/
/* RestorePal -Ramene toutes les couleurs a leurs etat initial              */
/****************************************************************************/
void RestorePal()
{
   WaitRetrace();
   for (int col=0;col<256;col++)
		 SetPal(col,Pal[col][0],Pal[col][1],Pal[col][2]);
}










/****************************************************************************/
/* Line - Dessine une ligne de x1,y1 a x2,y2 avec l'algo de Bresenham       */
/****************************************************************************/
void Line(short int x1, short int y1, short int x2, short int y2, byte col)
{
 short int dx, dy, sdx, sdy, x, y, px, py;

 x = 0;
 y = 0;
 dx = x2 - x1;
 dy = y2 - y1;
 sdx = (dx < 0) ? -1 : 1;
 sdy = (dy < 0) ? -1 : 1;
 dx = sdx * dx + 1;
 dy = sdy * dy + 1;
 px = x1;
 py = y1;

 if (dx >= dy)
 {
	for (x = 0; x < dx; x++)
	{
		Putpixel(px,py,col);
		y += dy;
		if (y >= dx)
		{
			y -= dx;
			py += sdy;
		}
		px += sdx;
	}
 }
   else
 {
	for (y = 0; y < dy; y++)
	{
		Putpixel(px,py,col);
		x += dx;
		if (x >= dy)
		{
			x -= dy;
			px += sdx;
		}
		py += sdy;
	}
 }
}

void Circle(short x, short y, short hauteur, float freq, byte col)
{
  short i;
  short point1[319];
  short point2[319];
  float wave = 1;

  for (i=0; i<319; i++)
  {
	point1[i] = (sin(wave)*hauteur);
	point2[i] = (cos(wave)*hauteur);
	wave += freq;
	Putpixel (point2[i]+x, point1[i]+y, col);
  }
}

void LineSin(short y, short hauteur, float freq, byte col)
{

 float wave = 0;
 short i;
 short point[319];

  for (i=0; i<319; i++)
  {
	point[i] = ((sin(wave)*hauteur)+y);
	wave += freq;
	Putpixel(i, point[i], col);
  }
}
