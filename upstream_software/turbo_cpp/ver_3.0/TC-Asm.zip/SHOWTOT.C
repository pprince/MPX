extern int StartingValue;
extern int DoTotal(void);
int Repetitions;
main()
{
   int i;
   Repetitions = 10;
   StartingValue = 2;
   printf("%d\n", DoTotal());
}
