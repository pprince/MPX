
/*
                              GameSpeed SFX

                         GAMESPED.H - header file

                           Author - Matt Voight
                            Copyright (c) 1993
                               Version  1.1
*/


#define TRUE  1
#define FALSE 0

#define GET   0                 /*  used with win_system() function  */
#define PUT   1

#define SOLID           0       /*  line style settings  */
#define LONG_DOTTED     1
#define LONG_DASHED     2
#define SHORT_DASHED    3
#define SHORT_DOTTED    4
#define RODS            5

#define T_BOTTOM        0       /* page transfer types  */
#define T_TOP           1
#define T_LEFT			3
#define T_RIGHT       	2
#define T_TOP_BOTTOM  	4
#define T_RIGHT_LEFT	5

#define J_NO_BUTTON     240     /*      Joystick button status     */
#define J_TOP_BUTTON    224
#define J_BOTTOM_BUTTON 208
#define J_BOTH_BUTTONS  192

#define M_NO_BUTTON     0       /*      Mouse button status        */
#define M_LEFT_BUTTON   1
#define M_RIGHT_BUTTON  2
#define M_BOTH_BUTTONS	3

#define UP    72            /*  arrow key ASCII designations  */
#define DOWN  80
#define RIGHT 77
#define LEFT  75
#define PGUP  73
#define PGDN  81
#define HOME  71
#define END   79

#define F1  59              /*  function key ASCII designations  */
#define F2  60
#define F3  61
#define F4  62
#define F5  63
#define F6  64
#define F7  65
#define F8  66
#define F9  67
#define F10 68

#define ctrlF1 94           /*  self-explanatory!!!  */
#define ctrlF2 95
#define ctrlF3 96
#define ctrlF4 97
#define ctrlF5 98
#define ctrlF6 99
#define ctrlF7 100
#define ctrlF8 101
#define ctrlF9 102
#define ctrlF10 103

#define altF1 104
#define altF2 105
#define altF3 106
#define altF4 107
#define altF5 108
#define altF6 109
#define altF7 110
#define altF8 111
#define altF9 112
#define altF10 113

#define shftF1 84
#define shftF2 85
#define shftF3 86
#define shftF4 87
#define shftF5 88
#define shftF6 89
#define shftF7 90
#define shftF8 91
#define shftF9 92
#define shftF10 93

#define ESC   27
#define SPACE 32
#define ENTER 13

